"use client";

import { signOut, useSession } from "next-auth/react";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getRoleLabel } from "@/lib/rbac";
import type { Role } from "@prisma/client";

export function Header({ title }: { title: string }) {
  const { data: session } = useSession();

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b bg-background/95 px-4 backdrop-blur supports-[backdrop-filter]:bg-background/60 lg:px-8">
      <div>
        <h1 className="text-xl font-bold">{title}</h1>
        {session?.user && (
          <p className="text-sm text-muted-foreground">
            {session.user.name} · {getRoleLabel(session.user.role as Role)}
          </p>
        )}
      </div>
      <Button variant="outline" size="sm" onClick={() => signOut({ callbackUrl: "/login" })}>
        <LogOut className="h-4 w-4" />
        خروج
      </Button>
    </header>
  );
}
