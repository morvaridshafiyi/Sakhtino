import { auth } from "@/lib/auth";
import { hasPermission } from "@/lib/rbac";
import {
  createIncome,
  createExpense,
  createInvoice,
  getFinanceOverview,
} from "@/features/finance/services";
import {
  incomeSchema,
  expenseSchema,
  invoiceSchema,
} from "@/lib/validations";
import { generateInvoiceNumber } from "@/lib/utils";
import { logActivity, rateLimit } from "@/lib/security";
import { Role } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!hasPermission(session.user.role as Role, "finance:read")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const overview = await getFinanceOverview();
  return NextResponse.json(overview);
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!hasPermission(session.user.role as Role, "finance:write")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const ip = req.headers.get("x-forwarded-for") ?? "anonymous";
  const { success } = await rateLimit(`finance:${ip}`);
  if (!success) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  const body = await req.json();
  const { type, ...data } = body;

  if (type === "income") {
    const parsed = incomeSchema.safeParse(data);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }
    const income = await createIncome({
      ...parsed.data,
      date: new Date(parsed.data.date),
    });
    await logActivity({
      userId: session.user.id,
      action: "CREATE",
      entity: "Income",
      entityId: income.id,
      ipAddress: ip,
    });
    return NextResponse.json(income, { status: 201 });
  }

  if (type === "expense") {
    const parsed = expenseSchema.safeParse(data);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }
    const expense = await createExpense({
      ...parsed.data,
      date: new Date(parsed.data.date),
    });
    await logActivity({
      userId: session.user.id,
      action: "CREATE",
      entity: "Expense",
      entityId: expense.id,
      ipAddress: ip,
    });
    return NextResponse.json(expense, { status: 201 });
  }

  if (type === "invoice") {
    const parsed = invoiceSchema.safeParse({
      ...data,
      invoiceNumber: data.invoiceNumber || generateInvoiceNumber(),
    });
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }
    const total = parsed.data.amount + parsed.data.tax;
    const invoice = await createInvoice({
      ...parsed.data,
      total,
      issueDate: new Date(parsed.data.issueDate),
      dueDate: new Date(parsed.data.dueDate),
    });
    return NextResponse.json(invoice, { status: 201 });
  }

  return NextResponse.json({ error: "Invalid type" }, { status: 400 });
}
