import { auth } from "@/lib/auth";
import {
  getDashboardStats,
  getMonthlyFinanceChart,
  getProjectProgressChart,
} from "@/features/dashboard/services";
import { rateLimit } from "@/lib/security";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const ip = req.headers.get("x-forwarded-for") ?? "anonymous";
  const { success } = await rateLimit(`dashboard:${ip}`);
  if (!success) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  const [stats, financeChart, progressChart] = await Promise.all([
    getDashboardStats(),
    getMonthlyFinanceChart(),
    getProjectProgressChart(),
  ]);

  return NextResponse.json({ stats, financeChart, progressChart });
}
