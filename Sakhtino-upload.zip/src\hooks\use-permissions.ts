"use client";

import { useSession } from "next-auth/react";
import { hasPermission, type Permission } from "@/lib/rbac";
import type { Role } from "@prisma/client";

export function usePermissions() {
  const { data: session } = useSession();
  const role = session?.user?.role as Role | undefined;

  return {
    can: (permission: Permission) =>
      role ? hasPermission(role, permission) : false,
    role,
    user: session?.user,
  };
}
