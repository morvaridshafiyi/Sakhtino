import { prisma } from "@/lib/prisma";

export async function getMaterials() {
  return prisma.material.findMany({
    include: {
      supplier: { select: { name: true } },
      _count: { select: { purchases: true } },
    },
    orderBy: { name: "asc" },
  });
}

export async function getSuppliers() {
  return prisma.supplier.findMany({
    where: { isActive: true },
    include: { _count: { select: { materials: true } } },
    orderBy: { name: "asc" },
  });
}

export async function createMaterial(data: {
  name: string;
  sku?: string;
  unit: string;
  quantity: number;
  minStock: number;
  unitCost: number;
  supplierId?: string;
  description?: string;
}) {
  return prisma.material.create({ data });
}

export async function createMaterialPurchase(data: {
  materialId: string;
  supplierId?: string;
  projectId?: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
  notes?: string;
}) {
  return prisma.$transaction(async (tx) => {
    const purchase = await tx.materialPurchase.create({ data });
    await tx.material.update({
      where: { id: data.materialId },
      data: { quantity: { increment: data.quantity } },
    });
    return purchase;
  });
}

export async function createSupplier(data: {
  name: string;
  phone?: string;
  email?: string;
  address?: string;
  notes?: string;
}) {
  return prisma.supplier.create({ data });
}

export async function getLowStockMaterials() {
  const materials = await prisma.material.findMany({
    include: { supplier: { select: { name: true } } },
  });
  return materials.filter((m) => Number(m.quantity) <= Number(m.minStock));
}
