import { auth } from "@/lib/auth";
import { hasPermission } from "@/lib/rbac";
import { createWorker, getWorkers } from "@/features/workers/services";
import { workerSchema } from "@/lib/validations";
import { logActivity, rateLimit } from "@/lib/security";
import { Role } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!hasPermission(session.user.role as Role, "workers:read")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const workers = await getWorkers();
  return NextResponse.json(workers);
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!hasPermission(session.user.role as Role, "workers:write")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const ip = req.headers.get("x-forwarded-for") ?? "anonymous";
  const { success } = await rateLimit(`workers:${ip}`);
  if (!success) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  const body = await req.json();
  const parsed = workerSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const worker = await createWorker(parsed.data);
  await logActivity({
    userId: session.user.id,
    action: "CREATE",
    entity: "Worker",
    entityId: worker.id,
    ipAddress: ip,
  });

  return NextResponse.json(worker, { status: 201 });
}
