import { createMetadata } from "@/lib/seo";

export const metadata = createMetadata({
  title: "ورود",
  path: "/login",
  noIndex: true,
});

export default function LoginLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return children;
}
