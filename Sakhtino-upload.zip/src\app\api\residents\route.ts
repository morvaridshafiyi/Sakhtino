import { auth } from "@/lib/auth";
import { hasPermission } from "@/lib/rbac";
import { getResidents, createResident } from "@/features/residents/services";
import { residentSchema } from "@/lib/validations";
import { logActivity, rateLimit } from "@/lib/security";
import { Role } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (!hasPermission(session.user.role as Role, "residents:read")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const projectId = req.nextUrl.searchParams.get("projectId") ?? undefined;
  const unitId = req.nextUrl.searchParams.get("unitId") ?? undefined;
  const residents = await getResidents({ projectId, unitId });
  return NextResponse.json(residents);
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (!hasPermission(session.user.role as Role, "residents:write")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const ip = req.headers.get("x-forwarded-for") ?? "anonymous";
  const { success } = await rateLimit(`residents:${ip}`);
  if (!success) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  const body = await req.json();
  const parsed = residentSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const resident = await createResident({
    ...parsed.data,
    moveInDate: parsed.data.moveInDate
      ? new Date(parsed.data.moveInDate)
      : undefined,
  });
  await logActivity({
    userId: session.user.id,
    action: "CREATE",
    entity: "Resident",
    entityId: resident.id,
    ipAddress: ip,
  });
  return NextResponse.json(resident, { status: 201 });
}
