import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import type { FieldValues, Resolver } from "react-hook-form";
import {
  ProjectStatus,
  InvoiceStatus,
  Role,
  UnitType,
  ResidentType,
  MaintenanceStatus,
  MaintenancePriority,
  MaintenanceCategory,
} from "@prisma/client";

export const loginSchema = z.object({
  email: z.string().email("ایمیل معتبر وارد کنید"),
  password: z.string().min(6, "رمز عبور حداقل ۶ کاراکتر"),
});

export const projectSchema = z.object({
  name: z.string().min(2, "نام ساختمان الزامی است"),
  description: z.string().optional(),
  address: z.string().optional(),
  status: z.nativeEnum(ProjectStatus),
  progress: z.coerce.number().min(0).max(100),
  budget: z.coerce.number().min(0),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  managerId: z.string().min(1),
});

export const incomeSchema = z.object({
  title: z.string().min(2, "عنوان الزامی است"),
  amount: z.coerce.number().positive("مبلغ باید مثبت باشد"),
  description: z.string().optional(),
  date: z.string(),
  category: z.string().optional(),
  projectId: z.string().optional(),
});

export const expenseSchema = z.object({
  title: z.string().min(2, "عنوان الزامی است"),
  amount: z.coerce.number().positive("مبلغ باید مثبت باشد"),
  description: z.string().optional(),
  date: z.string(),
  category: z.string().optional(),
  projectId: z.string().optional(),
});

export const invoiceSchema = z.object({
  invoiceNumber: z.string().min(1),
  clientName: z.string().min(2),
  amount: z.coerce.number().positive(),
  tax: z.coerce.number().min(0).default(0),
  status: z.nativeEnum(InvoiceStatus),
  issueDate: z.string(),
  dueDate: z.string(),
  notes: z.string().optional(),
  projectId: z.string().optional(),
});

export const workerSchema = z.object({
  firstName: z.string().min(2),
  lastName: z.string().min(2),
  nationalId: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  address: z.string().optional(),
  position: z.string().optional(),
  dailyWage: z.coerce.number().optional(),
  monthlySalary: z.coerce.number().optional(),
});

export const contractorSchema = z.object({
  name: z.string().min(2),
  company: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  address: z.string().optional(),
  specialty: z.string().optional(),
  notes: z.string().optional(),
});

export const materialSchema = z.object({
  name: z.string().min(2),
  sku: z.string().optional(),
  unit: z.string().min(1),
  quantity: z.coerce.number().min(0),
  minStock: z.coerce.number().min(0),
  unitCost: z.coerce.number().min(0),
  supplierId: z.string().optional(),
  description: z.string().optional(),
});

export const supplierSchema = z.object({
  name: z.string().min(2),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  address: z.string().optional(),
  notes: z.string().optional(),
});

export const userSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(6).optional(),
  role: z.nativeEnum(Role),
});

export const unitSchema = z.object({
  projectId: z.string().min(1, "ساختمان الزامی است"),
  unitNumber: z.string().min(1, "شماره واحد الزامی است"),
  floor: z.coerce.number().optional(),
  area: z.coerce.number().optional(),
  type: z.nativeEnum(UnitType),
  baseCharge: z.coerce.number().min(0, "مبلغ شارژ نمی‌تواند منفی باشد"),
  notes: z.string().optional(),
});

export const residentSchema = z.object({
  unitId: z.string().min(1, "واحد الزامی است"),
  name: z.string().min(2, "نام الزامی است"),
  phone: z.string().optional(),
  email: z.string().email().optional().or(z.literal("")),
  nationalId: z.string().optional(),
  type: z.nativeEnum(ResidentType),
  moveInDate: z.string().optional(),
  notes: z.string().optional(),
});

export const monthlyChargeSchema = z.object({
  unitId: z.string().min(1),
  projectId: z.string().min(1),
  year: z.coerce.number().min(1400).max(1500),
  month: z.coerce.number().min(1).max(12),
  amount: z.coerce.number().positive("مبلغ باید مثبت باشد"),
  dueDate: z.string(),
  description: z.string().optional(),
});

export const generateChargesSchema = z.object({
  projectId: z.string().min(1),
  year: z.coerce.number().min(1400).max(1500),
  month: z.coerce.number().min(1).max(12),
  dueDate: z.string(),
});

export const unitPaymentSchema = z.object({
  unitId: z.string().min(1),
  projectId: z.string().min(1),
  amount: z.coerce.number().positive("مبلغ باید مثبت باشد"),
  monthlyChargeId: z.string().optional(),
  paymentDate: z.string().optional(),
  method: z.string().optional(),
  reference: z.string().optional(),
  notes: z.string().optional(),
});

export const maintenanceTaskSchema = z.object({
  projectId: z.string().min(1),
  unitId: z.string().optional(),
  title: z.string().min(2, "عنوان الزامی است"),
  description: z.string().optional(),
  category: z.nativeEnum(MaintenanceCategory),
  priority: z.nativeEnum(MaintenancePriority),
  estimatedCost: z.coerce.number().optional(),
  scheduledDate: z.string().optional(),
  assignedTo: z.string().optional(),
});

export const buildingExpenseSchema = z.object({
  projectId: z.string().min(1),
  title: z.string().min(2, "عنوان الزامی است"),
  amount: z.coerce.number().positive("مبلغ باید مثبت باشد"),
  date: z.string(),
  category: z.string().optional(),
  description: z.string().optional(),
});

export type LoginInput = z.infer<typeof loginSchema>;
export type ProjectInput = z.infer<typeof projectSchema>;
export type IncomeInput = z.infer<typeof incomeSchema>;
export type ExpenseInput = z.infer<typeof expenseSchema>;
export type InvoiceInput = z.infer<typeof invoiceSchema>;
export type WorkerInput = z.infer<typeof workerSchema>;
export type ContractorInput = z.infer<typeof contractorSchema>;
export type MaterialInput = z.infer<typeof materialSchema>;
export type SupplierInput = z.infer<typeof supplierSchema>;
export type UnitInput = z.infer<typeof unitSchema>;
export type ResidentInput = z.infer<typeof residentSchema>;
export type MonthlyChargeInput = z.infer<typeof monthlyChargeSchema>;
export type UnitPaymentInput = z.infer<typeof unitPaymentSchema>;
export type MaintenanceTaskInput = z.infer<typeof maintenanceTaskSchema>;
export type BuildingExpenseInput = z.infer<typeof buildingExpenseSchema>;

export function formResolver<T extends FieldValues>(
  schema: z.ZodType<T>,
): Resolver<T> {
  // Zod v4 coerce fields widen input types; cast keeps react-hook-form happy.
  return zodResolver(schema as never) as Resolver<T>;
}
