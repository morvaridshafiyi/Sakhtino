import { PaymentStatus } from "@prisma/client";

export function computeChargeStatus(
  amount: number,
  paidAmount: number,
  dueDate: Date,
): PaymentStatus {
  if (paidAmount >= amount) return PaymentStatus.PAID;
  if (paidAmount > 0) return PaymentStatus.PARTIAL;
  if (new Date() > dueDate) return PaymentStatus.OVERDUE;
  return PaymentStatus.PENDING;
}

export function computeUnitBalance(totalCharges: number, totalPayments: number) {
  const balance = totalCharges - totalPayments;
  return {
    debt: Math.max(0, balance),
    credit: Math.max(0, -balance),
    balance,
  };
}

export function computeFundBalance(totalReceived: number, totalExpenses: number) {
  return totalReceived - totalExpenses;
}

export function getMonthRange(year: number, month: number) {
  const start = new Date(year, month - 1, 1);
  const end = new Date(year, month, 0, 23, 59, 59, 999);
  return { start, end };
}

export const chargeStatusLabels: Record<PaymentStatus, string> = {
  PENDING: "در انتظار",
  PARTIAL: "پرداخت ناقص",
  PAID: "پرداخت شده",
  OVERDUE: "معوق",
};

export const maintenanceStatusLabels = {
  PENDING: "در انتظار",
  IN_PROGRESS: "در حال انجام",
  COMPLETED: "انجام شده",
  CANCELLED: "لغو شده",
} as const;

export const maintenanceCategoryLabels = {
  CLEANING: "نظافت",
  PARKING: "پارکینگ",
  LIGHTING: "روشنایی و لامپ",
  PLUMBING: "لوله‌کشی و تأسیسات",
  ELEVATOR: "آسانسور",
  SECURITY: "نگهبانی و امنیت",
  GENERAL: "عمومی",
} as const;

export const maintenancePriorityLabels = {
  LOW: "کم",
  MEDIUM: "متوسط",
  HIGH: "بالا",
  URGENT: "فوری",
} as const;

export const unitTypeLabels = {
  RESIDENTIAL: "مسکونی",
  COMMERCIAL: "تجاری",
  PARKING: "پارکینگ",
  STORAGE: "انباری",
} as const;

export const residentTypeLabels = {
  OWNER: "مالک",
  TENANT: "مستأجر",
} as const;
