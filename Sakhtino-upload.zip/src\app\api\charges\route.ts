import { auth } from "@/lib/auth";
import { hasPermission } from "@/lib/rbac";
import {
  getMonthlyCharges,
  createMonthlyCharge,
  generateMonthlyChargesForBuilding,
  recordUnitPayment,
  getUnitPayments,
} from "@/features/charges/services";
import {
  monthlyChargeSchema,
  generateChargesSchema,
  unitPaymentSchema,
} from "@/lib/validations";
import { logActivity, rateLimit } from "@/lib/security";
import { Role, PaymentStatus } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (!hasPermission(session.user.role as Role, "finance:read")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const params = req.nextUrl.searchParams;
  const type = params.get("type");

  if (type === "payments") {
    const payments = await getUnitPayments({
      projectId: params.get("projectId") ?? undefined,
      unitId: params.get("unitId") ?? undefined,
      year: params.get("year") ? Number(params.get("year")) : undefined,
      month: params.get("month") ? Number(params.get("month")) : undefined,
    });
    return NextResponse.json(payments);
  }

  const charges = await getMonthlyCharges({
    projectId: params.get("projectId") ?? undefined,
    unitId: params.get("unitId") ?? undefined,
    year: params.get("year") ? Number(params.get("year")) : undefined,
    month: params.get("month") ? Number(params.get("month")) : undefined,
    status: (params.get("status") as PaymentStatus) ?? undefined,
  });
  return NextResponse.json(charges);
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (!hasPermission(session.user.role as Role, "finance:write")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const ip = req.headers.get("x-forwarded-for") ?? "anonymous";
  const { success } = await rateLimit(`charges:${ip}`);
  if (!success) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  const body = await req.json();
  const { type, ...data } = body;

  if (type === "charge") {
    const parsed = monthlyChargeSchema.safeParse(data);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }
    const charge = await createMonthlyCharge({
      ...parsed.data,
      dueDate: new Date(parsed.data.dueDate),
    });
    await logActivity({
      userId: session.user.id,
      action: "CREATE",
      entity: "MonthlyCharge",
      entityId: charge.id,
      ipAddress: ip,
    });
    return NextResponse.json(charge, { status: 201 });
  }

  if (type === "generate") {
    const parsed = generateChargesSchema.safeParse(data);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }
    const charges = await generateMonthlyChargesForBuilding(
      parsed.data.projectId,
      parsed.data.year,
      parsed.data.month,
      new Date(parsed.data.dueDate),
    );
    return NextResponse.json({ count: charges.length, charges }, { status: 201 });
  }

  if (type === "payment") {
    const parsed = unitPaymentSchema.safeParse(data);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }
    const payment = await recordUnitPayment({
      ...parsed.data,
      paymentDate: parsed.data.paymentDate
        ? new Date(parsed.data.paymentDate)
        : undefined,
    });
    await logActivity({
      userId: session.user.id,
      action: "CREATE",
      entity: "UnitPayment",
      entityId: payment.id,
      ipAddress: ip,
    });
    return NextResponse.json(payment, { status: 201 });
  }

  return NextResponse.json({ error: "Invalid type" }, { status: 400 });
}
