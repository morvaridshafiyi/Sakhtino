import { prisma } from "@/lib/prisma";
import { NotificationType } from "@prisma/client";

export async function getNotifications(userId: string) {
  return prisma.notification.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
}

export async function getUnreadCount(userId: string) {
  return prisma.notification.count({
    where: { userId, isRead: false },
  });
}

export async function markAsRead(id: string, userId: string) {
  return prisma.notification.updateMany({
    where: { id, userId },
    data: { isRead: true },
  });
}

export async function createNotification(data: {
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  link?: string;
}) {
  return prisma.notification.create({ data });
}

export async function generateDuePaymentReminders() {
  const overdueInvoices = await prisma.invoice.findMany({
    where: {
      status: { in: ["SENT", "OVERDUE"] },
      dueDate: { lt: new Date() },
    },
  });

  const managers = await prisma.user.findMany({
    where: { role: { in: ["SUPER_ADMIN", "BUILDING_MANAGER", "ACCOUNTANT"] } },
  });

  for (const invoice of overdueInvoices) {
    for (const user of managers) {
      await createNotification({
        userId: user.id,
        type: "PAYMENT_DUE",
        title: "سررسید پرداخت",
        message: `فاکتور ${invoice.invoiceNumber} سررسید گذشته است.`,
        link: "/charges",
      });
    }
  }
}

export async function generateMaintenanceReminders() {
  const urgentTasks = await prisma.maintenanceTask.findMany({
    where: {
      status: { in: ["PENDING", "IN_PROGRESS"] },
      priority: "HIGH",
    },
    include: { project: { select: { name: true, managerId: true } } },
    take: 20,
  });

  for (const task of urgentTasks) {
    await createNotification({
      userId: task.project.managerId,
      type: "PROJECT_DEADLINE",
      title: "کار اجرایی فوری",
      message: `«${task.title}» در ساختمان ${task.project.name} نیاز به پیگیری دارد.`,
      link: "/maintenance",
    });
  }
}
