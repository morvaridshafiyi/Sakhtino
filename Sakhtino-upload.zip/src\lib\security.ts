import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";

type RateLimitOptions = {
  limit: number;
  windowMs: number;
};

const store = new Map<string, { count: number; resetAt: number }>();

export async function rateLimit(
  key: string,
  options: RateLimitOptions = { limit: 60, windowMs: 60_000 },
): Promise<{ success: boolean; remaining: number }> {
  const now = Date.now();
  const entry = store.get(key);

  if (!entry || now > entry.resetAt) {
    store.set(key, { count: 1, resetAt: now + options.windowMs });
    return { success: true, remaining: options.limit - 1 };
  }

  if (entry.count >= options.limit) {
    return { success: false, remaining: 0 };
  }

  entry.count += 1;
  return { success: true, remaining: options.limit - entry.count };
}

export async function logActivity(params: {
  userId?: string;
  projectId?: string;
  action: string;
  entity: string;
  entityId?: string;
  metadata?: Record<string, unknown>;
  ipAddress?: string;
}) {
  await prisma.activityLog.create({
    data: {
      userId: params.userId,
      projectId: params.projectId,
      action: params.action,
      entity: params.entity,
      entityId: params.entityId,
      metadata: params.metadata as Prisma.InputJsonValue | undefined,
      ipAddress: params.ipAddress,
    },
  });
}
