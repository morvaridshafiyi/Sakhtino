import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";

type ReportRow = Record<string, string | number>;

export function exportToPDF(
  title: string,
  columns: string[],
  rows: ReportRow[],
  filename: string,
) {
  const doc = new jsPDF({ orientation: "landscape" });
  doc.setFont("helvetica");
  doc.setFontSize(16);
  doc.text(title, 14, 20);

  autoTable(doc, {
    head: [columns],
    body: rows.map((row) => columns.map((col) => String(row[col] ?? ""))),
    startY: 30,
    styles: { font: "helvetica", fontSize: 10 },
  });

  doc.save(`${filename}.pdf`);
}

export function exportToExcel(
  data: ReportRow[],
  sheetName: string,
  filename: string,
) {
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  XLSX.writeFile(workbook, `${filename}.xlsx`);
}

export function buildFinancialSummary(data: {
  totalIncome: number;
  totalExpense: number;
  netProfit: number;
  period: string;
}) {
  return [
    { metric: "دوره", value: data.period },
    { metric: "کل درآمد", value: data.totalIncome },
    { metric: "کل هزینه", value: data.totalExpense },
    { metric: "سود/زیان", value: data.netProfit },
  ];
}
