import { prisma } from "@/lib/prisma";
import { PaymentStatus } from "@prisma/client";
import { startOfMonth, endOfMonth, subMonths, format } from "date-fns";
import { faIR } from "date-fns/locale";
import { getBuildingFinancialSummary } from "@/features/building-finance/services";

export async function getDashboardStats() {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + 1;

  const [
    totalBuildings,
    activeUnits,
    residentsCount,
    buildingFinance,
    overdueCharges,
    openMaintenance,
    recentActivities,
  ] = await Promise.all([
    prisma.project.count({ where: { isArchived: false } }),
    prisma.unit.count({ where: { isActive: true } }),
    prisma.resident.count({ where: { isActive: true } }),
    getBuildingFinancialSummary(undefined, { year, month }),
    prisma.monthlyCharge.count({ where: { status: PaymentStatus.OVERDUE } }),
    prisma.maintenanceTask.count({
      where: { status: { in: ["PENDING", "IN_PROGRESS"] } },
    }),
    prisma.activityLog.findMany({
      take: 10,
      orderBy: { createdAt: "desc" },
      include: { user: { select: { name: true } } },
    }),
  ]);

  return {
    totalBuildings,
    activeUnits,
    residentsCount,
    monthlyIncome: buildingFinance.totalReceived,
    monthlyExpenses: buildingFinance.totalExpenses,
    fundBalance: buildingFinance.fundBalance,
    outstandingDebt: buildingFinance.outstandingDebt,
    unitsWithDebt: buildingFinance.unitsWithDebt,
    overdueCharges,
    openMaintenance,
    recentActivities,
  };
}

export async function getMonthlyFinanceChart() {
  const months = Array.from({ length: 6 }, (_, i) => {
    const date = subMonths(new Date(), 5 - i);
    return {
      date,
      name: format(date, "MMM", { locale: faIR }),
      start: startOfMonth(date),
      end: endOfMonth(date),
    };
  });

  const data = await Promise.all(
    months.map(async (month) => {
      const [payments, expense] = await Promise.all([
        prisma.unitPayment.aggregate({
          where: { paymentDate: { gte: month.start, lte: month.end } },
          _sum: { amount: true },
        }),
        prisma.expense.aggregate({
          where: { date: { gte: month.start, lte: month.end } },
          _sum: { amount: true },
        }),
      ]);

      return {
        name: month.name,
        income: Number(payments._sum.amount ?? 0),
        expense: Number(expense._sum.amount ?? 0),
      };
    }),
  );

  return data;
}

export async function getProjectProgressChart() {
  const buildings = await prisma.project.findMany({
    where: { isArchived: false },
    take: 5,
    orderBy: { updatedAt: "desc" },
    select: {
      name: true,
      _count: { select: { units: true } },
    },
  });

  return buildings.map((p) => ({
    name: p.name.length > 15 ? `${p.name.slice(0, 15)}...` : p.name,
    value: p._count.units,
  }));
}
