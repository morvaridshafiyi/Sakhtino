import { auth } from "@/lib/auth";
import { hasPermission } from "@/lib/rbac";
import {
  createMaterial,
  createMaterialPurchase,
  createSupplier,
  getMaterials,
  getSuppliers,
} from "@/features/materials/services";
import { materialSchema, supplierSchema } from "@/lib/validations";
import { logActivity, rateLimit } from "@/lib/security";
import { Role } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!hasPermission(session.user.role as Role, "materials:read")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const type = req.nextUrl.searchParams.get("type");
  if (type === "suppliers") {
    return NextResponse.json(await getSuppliers());
  }

  return NextResponse.json(await getMaterials());
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!hasPermission(session.user.role as Role, "materials:write")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const ip = req.headers.get("x-forwarded-for") ?? "anonymous";
  const { success } = await rateLimit(`materials:${ip}`);
  if (!success) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  const body = await req.json();
  const { type, ...data } = body;

  if (type === "supplier") {
    const parsed = supplierSchema.safeParse(data);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }
    const supplier = await createSupplier(parsed.data);
    return NextResponse.json(supplier, { status: 201 });
  }

  if (type === "purchase") {
    const totalCost = data.quantity * data.unitCost;
    const purchase = await createMaterialPurchase({ ...data, totalCost });
    await logActivity({
      userId: session.user.id,
      action: "CREATE",
      entity: "MaterialPurchase",
      entityId: purchase.id,
      ipAddress: ip,
    });
    return NextResponse.json(purchase, { status: 201 });
  }

  const parsed = materialSchema.safeParse(data);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const material = await createMaterial(parsed.data);
  await logActivity({
    userId: session.user.id,
    action: "CREATE",
    entity: "Material",
    entityId: material.id,
    ipAddress: ip,
  });

  return NextResponse.json(material, { status: 201 });
}
