"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Label } from "@/components/ui/label";

type Option = { id: string; name: string };

type MonthFilterProps = {
  projects?: Option[];
  showProject?: boolean;
};

export function MonthFilter({ projects = [], showProject = true }: MonthFilterProps) {
  const router = useRouter();
  const params = useSearchParams();
  const now = new Date();

  const year = params.get("year") ?? String(now.getFullYear());
  const month = params.get("month") ?? String(now.getMonth() + 1);
  const projectId = params.get("projectId") ?? "";

  function update(key: string, value: string) {
    const next = new URLSearchParams(params.toString());
    if (value) next.set(key, value);
    else next.delete(key);
    router.push(`?${next.toString()}`);
  }

  const years = Array.from({ length: 3 }, (_, i) => now.getFullYear() - 1 + i);

  return (
    <div className="flex flex-wrap items-end gap-4 rounded-lg border bg-card p-4">
      {showProject && projects.length > 0 && (
        <div className="space-y-2">
          <Label>ساختمان</Label>
          <select
            className="flex h-10 w-48 rounded-lg border border-input bg-background px-3 text-sm"
            value={projectId}
            onChange={(e) => update("projectId", e.target.value)}
          >
            <option value="">همه ساختمان‌ها</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </div>
      )}
      <div className="space-y-2">
        <Label>سال</Label>
        <select
          className="flex h-10 w-28 rounded-lg border border-input bg-background px-3 text-sm"
          value={year}
          onChange={(e) => update("year", e.target.value)}
        >
          {years.map((y) => (
            <option key={y} value={y}>
              {y}
            </option>
          ))}
        </select>
      </div>
      <div className="space-y-2">
        <Label>ماه</Label>
        <select
          className="flex h-10 w-28 rounded-lg border border-input bg-background px-3 text-sm"
          value={month}
          onChange={(e) => update("month", e.target.value)}
        >
          {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}
