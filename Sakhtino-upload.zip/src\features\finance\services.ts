import { prisma } from "@/lib/prisma";

export async function getFinanceOverview() {
  const [incomes, expenses, invoices, debts] = await Promise.all([
    prisma.income.findMany({ orderBy: { date: "desc" }, take: 20 }),
    prisma.expense.findMany({ orderBy: { date: "desc" }, take: 20 }),
    prisma.invoice.findMany({ orderBy: { issueDate: "desc" }, take: 20 }),
    prisma.debt.findMany({ orderBy: { createdAt: "desc" } }),
  ]);

  const totalIncome = incomes.reduce((sum, i) => sum + Number(i.amount), 0);
  const totalExpense = expenses.reduce((sum, e) => sum + Number(e.amount), 0);

  return {
    incomes,
    expenses,
    invoices,
    debts,
    totalIncome,
    totalExpense,
    netProfit: totalIncome - totalExpense,
  };
}

export async function createIncome(data: {
  title: string;
  amount: number;
  description?: string;
  date: Date;
  category?: string;
  projectId?: string;
}) {
  return prisma.income.create({ data });
}

export async function createExpense(data: {
  title: string;
  amount: number;
  description?: string;
  date: Date;
  category?: string;
  projectId?: string;
}) {
  return prisma.expense.create({ data });
}

export async function createInvoice(data: {
  invoiceNumber: string;
  clientName: string;
  amount: number;
  tax: number;
  total: number;
  status: "DRAFT" | "SENT" | "PAID" | "OVERDUE" | "CANCELLED";
  issueDate: Date;
  dueDate: Date;
  notes?: string;
  projectId?: string;
}) {
  return prisma.invoice.create({ data });
}
