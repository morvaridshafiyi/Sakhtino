import { auth } from "@/lib/auth";
import { hasPermission } from "@/lib/rbac";
import {
  getBuildingFinancialSummary,
  getMonthlyFinanceReport,
  createBuildingExpense,
} from "@/features/building-finance/services";
import { buildingExpenseSchema } from "@/lib/validations";
import { logActivity, rateLimit } from "@/lib/security";
import { Role } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (!hasPermission(session.user.role as Role, "finance:read")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const params = req.nextUrl.searchParams;
  const projectId = params.get("projectId") ?? undefined;
  const year = params.get("year") ? Number(params.get("year")) : undefined;
  const month = params.get("month") ? Number(params.get("month")) : undefined;

  if (params.get("report") === "monthly") {
    const report = await getMonthlyFinanceReport(projectId);
    return NextResponse.json(report);
  }

  const summary = await getBuildingFinancialSummary(
    projectId,
    year && month ? { year, month } : undefined,
  );
  return NextResponse.json(summary);
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (!hasPermission(session.user.role as Role, "finance:write")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const ip = req.headers.get("x-forwarded-for") ?? "anonymous";
  const { success } = await rateLimit(`building-finance:${ip}`);
  if (!success) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  const body = await req.json();
  const parsed = buildingExpenseSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const expense = await createBuildingExpense({
    ...parsed.data,
    date: new Date(parsed.data.date),
  });
  await logActivity({
    userId: session.user.id,
    action: "CREATE",
    entity: "Expense",
    entityId: expense.id,
    ipAddress: ip,
  });
  return NextResponse.json(expense, { status: 201 });
}
