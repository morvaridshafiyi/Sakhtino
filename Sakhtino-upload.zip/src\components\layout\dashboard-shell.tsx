import { Sidebar } from "./sidebar";

export function DashboardShell({
  children,
  title,
}: {
  children: React.ReactNode;
  title?: string;
}) {
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex flex-1 flex-col">
        <main className="flex-1 p-4 lg:p-8">
          <div className="mb-6 lg:hidden h-8" />
          {title && (
            <h1 className="mb-6 text-2xl font-bold lg:hidden">{title}</h1>
          )}
          {children}
        </main>
      </div>
    </div>
  );
}
