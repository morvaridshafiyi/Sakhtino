import { Metadata } from "next";

const appName = process.env.NEXT_PUBLIC_APP_NAME ?? "سامانه مدیریت ساختمان";
const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

type SEOProps = {
  title?: string;
  description?: string;
  path?: string;
  noIndex?: boolean;
  image?: string;
};

export function createMetadata({
  title,
  description = "سامانه مدیریت مالی و اجرایی ساختمان — شارژ، پرداخت، هزینه و کارهای نظافت و تعمیرات",
  path = "",
  noIndex = false,
  image = "/og-image.png",
}: SEOProps = {}): Metadata {
  const fullTitle = title ? `${title} | ${appName}` : appName;
  const url = `${appUrl}${path}`;
  const imageUrl = image.startsWith("http") ? image : `${appUrl}${image}`;

  return {
    title: fullTitle,
    description,
    metadataBase: new URL(appUrl),
    alternates: {
      canonical: url,
    },
    openGraph: {
      title: fullTitle,
      description,
      url,
      siteName: appName,
      locale: "fa_IR",
      type: "website",
      images: [{ url: imageUrl, width: 1200, height: 630, alt: fullTitle }],
    },
    twitter: {
      card: "summary_large_image",
      title: fullTitle,
      description,
      images: [imageUrl],
    },
    robots: noIndex
      ? { index: false, follow: false }
      : { index: true, follow: true },
  };
}

export function createOrganizationJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: appName,
    applicationCategory: "BusinessApplication",
    operatingSystem: "Web",
    offers: {
      "@type": "Offer",
      price: "0",
      priceCurrency: "IRR",
    },
    inLanguage: "fa",
  };
}

export { appName, appUrl };
