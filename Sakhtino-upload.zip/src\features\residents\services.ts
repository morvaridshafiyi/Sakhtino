import { prisma } from "@/lib/prisma";
import { ResidentType } from "@prisma/client";

export async function getResidents(filters: { projectId?: string; unitId?: string } = {}) {
  return prisma.resident.findMany({
    where: {
      unitId: filters.unitId,
      unit: filters.projectId ? { projectId: filters.projectId } : undefined,
    },
    include: {
      unit: {
        select: {
          id: true,
          unitNumber: true,
          floor: true,
          project: { select: { id: true, name: true } },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function createResident(data: {
  unitId: string;
  name: string;
  phone?: string;
  email?: string;
  nationalId?: string;
  type: ResidentType;
  moveInDate?: Date;
  notes?: string;
}) {
  return prisma.resident.create({ data });
}

export async function updateResident(
  id: string,
  data: Partial<{
    name: string;
    phone: string;
    email: string;
    nationalId: string;
    type: ResidentType;
    isActive: boolean;
    moveInDate: Date;
    moveOutDate: Date;
    notes: string;
  }>,
) {
  return prisma.resident.update({ where: { id }, data });
}
