import { prisma } from "@/lib/prisma";

export async function getContractors() {
  return prisma.contractor.findMany({
    where: { isActive: true },
    include: {
      _count: { select: { contracts: true, payments: true, projects: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function getContractorById(id: string) {
  return prisma.contractor.findUnique({
    where: { id },
    include: {
      contracts: { orderBy: { startDate: "desc" } },
      payments: { orderBy: { createdAt: "desc" } },
      projects: {
        include: { project: { select: { id: true, name: true, status: true } } },
      },
    },
  });
}

export async function createContractor(data: {
  name: string;
  company?: string;
  phone?: string;
  email?: string;
  address?: string;
  specialty?: string;
  notes?: string;
}) {
  return prisma.contractor.create({ data });
}

export async function createContract(data: {
  contractorId: string;
  title: string;
  amount: number;
  startDate: Date;
  endDate?: Date;
  description?: string;
}) {
  return prisma.contract.create({ data });
}
