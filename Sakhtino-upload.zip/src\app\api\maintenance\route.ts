import { auth } from "@/lib/auth";
import { hasPermission } from "@/lib/rbac";
import {
  getMaintenanceTasks,
  createMaintenanceTask,
  updateMaintenanceTask,
} from "@/features/maintenance/services";
import { maintenanceTaskSchema } from "@/lib/validations";
import { logActivity, rateLimit } from "@/lib/security";
import { MaintenanceStatus, Role } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (!hasPermission(session.user.role as Role, "maintenance:read")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const params = req.nextUrl.searchParams;
  const tasks = await getMaintenanceTasks({
    projectId: params.get("projectId") ?? undefined,
    unitId: params.get("unitId") ?? undefined,
    status: (params.get("status") as MaintenanceStatus) ?? undefined,
  });
  return NextResponse.json(tasks);
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (!hasPermission(session.user.role as Role, "maintenance:write")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const ip = req.headers.get("x-forwarded-for") ?? "anonymous";
  const { success } = await rateLimit(`maintenance:${ip}`);
  if (!success) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  const body = await req.json();
  const { action, id, ...data } = body;

  if (action === "update" && id) {
    const task = await updateMaintenanceTask(id, {
      ...data,
      scheduledDate: data.scheduledDate ? new Date(data.scheduledDate) : undefined,
      completedDate: data.completedDate ? new Date(data.completedDate) : undefined,
    });
    return NextResponse.json(task);
  }

  const parsed = maintenanceTaskSchema.safeParse(data);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const task = await createMaintenanceTask({
    ...parsed.data,
    unitId: parsed.data.unitId || undefined,
    scheduledDate: parsed.data.scheduledDate
      ? new Date(parsed.data.scheduledDate)
      : undefined,
  });
  await logActivity({
    userId: session.user.id,
    action: "CREATE",
    entity: "MaintenanceTask",
    entityId: task.id,
    ipAddress: ip,
  });
  return NextResponse.json(task, { status: 201 });
}
