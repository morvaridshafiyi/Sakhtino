declare module "jspdf-autotable" {
  import { jsPDF } from "jspdf";

  interface UserOptions {
    head?: (string | number)[][];
    body?: (string | number)[][];
    startY?: number;
    styles?: Record<string, unknown>;
  }

  export default function autoTable(doc: jsPDF, options: UserOptions): void;
}
