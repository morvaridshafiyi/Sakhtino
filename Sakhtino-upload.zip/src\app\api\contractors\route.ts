import { auth } from "@/lib/auth";
import { hasPermission } from "@/lib/rbac";
import {
  createContractor,
  getContractors,
} from "@/features/contractors/services";
import { contractorSchema } from "@/lib/validations";
import { logActivity, rateLimit } from "@/lib/security";
import { Role } from "@prisma/client";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!hasPermission(session.user.role as Role, "contractors:read")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const contractors = await getContractors();
  return NextResponse.json(contractors);
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!hasPermission(session.user.role as Role, "contractors:write")) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const ip = req.headers.get("x-forwarded-for") ?? "anonymous";
  const { success } = await rateLimit(`contractors:${ip}`);
  if (!success) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  const body = await req.json();
  const parsed = contractorSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const contractor = await createContractor(parsed.data);
  await logActivity({
    userId: session.user.id,
    action: "CREATE",
    entity: "Contractor",
    entityId: contractor.id,
    ipAddress: ip,
  });

  return NextResponse.json(contractor, { status: 201 });
}
