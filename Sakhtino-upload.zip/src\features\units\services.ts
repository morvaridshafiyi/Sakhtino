import { prisma } from "@/lib/prisma";
import { computeUnitBalance } from "@/lib/finance/calculations";
import { UnitType } from "@prisma/client";

export type UnitFilters = {
  projectId?: string;
  isActive?: boolean;
};

export async function getUnits(filters: UnitFilters = {}) {
  const units = await prisma.unit.findMany({
    where: {
      projectId: filters.projectId,
      isActive: filters.isActive,
    },
    include: {
      project: { select: { id: true, name: true } },
      residents: { where: { isActive: true }, take: 1 },
      _count: { select: { residents: true, monthlyCharges: true } },
    },
    orderBy: [{ floor: "asc" }, { unitNumber: "asc" }],
  });

  const unitIds = units.map((u) => u.id);
  const [chargeTotals, paymentTotals] = await Promise.all([
    prisma.monthlyCharge.groupBy({
      by: ["unitId"],
      where: { unitId: { in: unitIds } },
      _sum: { amount: true },
    }),
    prisma.unitPayment.groupBy({
      by: ["unitId"],
      where: { unitId: { in: unitIds } },
      _sum: { amount: true },
    }),
  ]);

  const chargeMap = new Map(
    chargeTotals.map((c) => [c.unitId, Number(c._sum.amount ?? 0)]),
  );
  const paymentMap = new Map(
    paymentTotals.map((p) => [p.unitId, Number(p._sum.amount ?? 0)]),
  );

  return units.map((unit) => {
    const charges = chargeMap.get(unit.id) ?? 0;
    const payments = paymentMap.get(unit.id) ?? 0;
    const { debt, credit } = computeUnitBalance(charges, payments);
    return { ...unit, totalCharges: charges, totalPayments: payments, debt, credit };
  });
}

export async function getUnitById(id: string) {
  const unit = await prisma.unit.findUnique({
    where: { id },
    include: {
      project: { select: { id: true, name: true } },
      residents: { orderBy: { createdAt: "desc" } },
      monthlyCharges: { orderBy: [{ year: "desc" }, { month: "desc" }], take: 12 },
      unitPayments: { orderBy: { paymentDate: "desc" }, take: 20 },
      maintenanceTasks: {
        where: { status: { not: "CANCELLED" } },
        orderBy: { createdAt: "desc" },
        take: 10,
      },
    },
  });

  if (!unit) return null;

  const [chargeSum, paymentSum] = await Promise.all([
    prisma.monthlyCharge.aggregate({
      where: { unitId: id },
      _sum: { amount: true, paidAmount: true },
    }),
    prisma.unitPayment.aggregate({
      where: { unitId: id },
      _sum: { amount: true },
    }),
  ]);

  const totalCharges = Number(chargeSum._sum.amount ?? 0);
  const totalPayments = Number(paymentSum._sum.amount ?? 0);
  const { debt, credit } = computeUnitBalance(totalCharges, totalPayments);

  return {
    ...unit,
    totalCharges,
    totalPayments,
    totalPaidOnCharges: Number(chargeSum._sum.paidAmount ?? 0),
    debt,
    credit,
  };
}

export async function createUnit(data: {
  projectId: string;
  unitNumber: string;
  floor?: number;
  area?: number;
  type: UnitType;
  baseCharge: number;
  notes?: string;
}) {
  return prisma.unit.create({ data });
}

export async function updateUnit(
  id: string,
  data: Partial<{
    unitNumber: string;
    floor: number;
    area: number;
    type: UnitType;
    baseCharge: number;
    isActive: boolean;
    notes: string;
  }>,
) {
  return prisma.unit.update({ where: { id }, data });
}
