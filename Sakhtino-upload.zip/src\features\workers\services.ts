import { prisma } from "@/lib/prisma";

export async function getWorkers() {
  return prisma.worker.findMany({
    where: { isActive: true },
    include: {
      _count: { select: { attendances: true, salaries: true } },
    },
    orderBy: { createdAt: "desc" },
  });
}

export async function getWorkerById(id: string) {
  return prisma.worker.findUnique({
    where: { id },
    include: {
      documents: true,
      attendances: { orderBy: { date: "desc" }, take: 30 },
      salaries: { orderBy: { createdAt: "desc" } },
      projects: { include: { project: { select: { name: true } } } },
    },
  });
}

export async function createWorker(data: {
  firstName: string;
  lastName: string;
  nationalId?: string;
  phone?: string;
  email?: string;
  address?: string;
  position?: string;
  dailyWage?: number;
  monthlySalary?: number;
}) {
  return prisma.worker.create({ data });
}

export async function updateWorker(
  id: string,
  data: Partial<{
    firstName: string;
    lastName: string;
    phone: string;
    email: string;
    position: string;
    dailyWage: number;
    monthlySalary: number;
    isActive: boolean;
  }>,
) {
  return prisma.worker.update({ where: { id }, data });
}

export async function recordAttendance(data: {
  workerId: string;
  date: Date;
  isPresent: boolean;
  hours?: number;
  notes?: string;
}) {
  return prisma.attendance.upsert({
    where: {
      workerId_date: { workerId: data.workerId, date: data.date },
    },
    create: data,
    update: {
      isPresent: data.isPresent,
      hours: data.hours,
      notes: data.notes,
    },
  });
}
