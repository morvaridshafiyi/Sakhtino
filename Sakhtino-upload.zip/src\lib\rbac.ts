import { Role } from "@prisma/client";

export type Permission =
  | "users:read"
  | "users:write"
  | "projects:read"
  | "projects:write"
  | "projects:archive"
  | "finance:read"
  | "finance:write"
  | "workers:read"
  | "workers:write"
  | "contractors:read"
  | "contractors:write"
  | "materials:read"
  | "materials:write"
  | "units:read"
  | "units:write"
  | "residents:read"
  | "residents:write"
  | "maintenance:read"
  | "maintenance:write"
  | "reports:read"
  | "reports:export"
  | "notifications:read"
  | "settings:write"
  | "audit:read";

const rolePermissions: Record<Role, Permission[]> = {
  SUPER_ADMIN: [
    "users:read",
    "users:write",
    "projects:read",
    "projects:write",
    "projects:archive",
    "finance:read",
    "finance:write",
    "workers:read",
    "workers:write",
    "contractors:read",
    "contractors:write",
    "materials:read",
    "materials:write",
    "units:read",
    "units:write",
    "residents:read",
    "residents:write",
    "maintenance:read",
    "maintenance:write",
    "reports:read",
    "reports:export",
    "notifications:read",
    "settings:write",
    "audit:read",
  ],
  BUILDING_MANAGER: [
    "projects:read",
    "projects:write",
    "projects:archive",
    "finance:read",
    "workers:read",
    "workers:write",
    "contractors:read",
    "contractors:write",
    "materials:read",
    "materials:write",
    "units:read",
    "units:write",
    "residents:read",
    "residents:write",
    "maintenance:read",
    "maintenance:write",
    "reports:read",
    "reports:export",
    "notifications:read",
  ],
  ACCOUNTANT: [
    "projects:read",
    "finance:read",
    "finance:write",
    "workers:read",
    "contractors:read",
    "materials:read",
    "units:read",
    "residents:read",
    "maintenance:read",
    "reports:read",
    "reports:export",
    "notifications:read",
  ],
  PROJECT_SUPERVISOR: [
    "projects:read",
    "projects:write",
    "workers:read",
    "workers:write",
    "materials:read",
    "materials:write",
    "units:read",
    "maintenance:read",
    "maintenance:write",
    "notifications:read",
  ],
};

export function hasPermission(role: Role, permission: Permission): boolean {
  return rolePermissions[role]?.includes(permission) ?? false;
}

export function hasAnyPermission(
  role: Role,
  permissions: Permission[],
): boolean {
  return permissions.some((p) => hasPermission(role, p));
}

export function getRoleLabel(role: Role): string {
  const labels: Record<Role, string> = {
    SUPER_ADMIN: "مدیر ارشد",
    BUILDING_MANAGER: "مدیر ساختمان",
    ACCOUNTANT: "حسابدار",
    PROJECT_SUPERVISOR: "سرپرست اجرایی",
  };
  return labels[role];
}

export const rolePermissionsMap = rolePermissions;
