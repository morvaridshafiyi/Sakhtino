import { prisma } from "@/lib/prisma";
import {
  computeFundBalance,
  computeUnitBalance,
  getMonthRange,
} from "@/lib/finance/calculations";
import { FinancialTransactionType, PaymentStatus } from "@prisma/client";

export type FinancePeriod = { year?: number; month?: number };

export async function getBuildingFinancialSummary(
  projectId?: string,
  period?: FinancePeriod,
) {
  const dateRange =
    period?.year && period?.month
      ? getMonthRange(period.year, period.month)
      : undefined;

  const chargeWhere = {
    projectId,
    ...(dateRange && {
      year: period!.year,
      month: period!.month,
    }),
  };

  const paymentWhere = {
    projectId,
    ...(dateRange && { paymentDate: { gte: dateRange.start, lte: dateRange.end } }),
  };

  const expenseWhere = {
    projectId,
    ...(dateRange && { date: { gte: dateRange.start, lte: dateRange.end } }),
  };

  const [
    chargeAgg,
    paymentAgg,
    expenseAgg,
    incomeAgg,
    overdueCharges,
    partialCharges,
    units,
    chargeByUnit,
    paymentByUnit,
    recentTransactions,
    openTasks,
  ] = await Promise.all([
    prisma.monthlyCharge.aggregate({
      where: chargeWhere,
      _sum: { amount: true, paidAmount: true },
      _count: true,
    }),
    prisma.unitPayment.aggregate({
      where: paymentWhere,
      _sum: { amount: true },
      _count: true,
    }),
    prisma.expense.aggregate({
      where: expenseWhere,
      _sum: { amount: true },
      _count: true,
    }),
    prisma.income.aggregate({
      where: expenseWhere,
      _sum: { amount: true },
    }),
    prisma.monthlyCharge.count({
      where: { ...chargeWhere, status: PaymentStatus.OVERDUE },
    }),
    prisma.monthlyCharge.count({
      where: { ...chargeWhere, status: PaymentStatus.PARTIAL },
    }),
    prisma.unit.count({ where: { projectId, isActive: true } }),
    prisma.monthlyCharge.groupBy({
      by: ["unitId"],
      where: projectId ? { projectId } : undefined,
      _sum: { amount: true },
    }),
    prisma.unitPayment.groupBy({
      by: ["unitId"],
      where: projectId ? { projectId } : undefined,
      _sum: { amount: true },
    }),
    prisma.financialTransaction.findMany({
      where: {
        projectId,
        ...(dateRange && { date: { gte: dateRange.start, lte: dateRange.end } }),
      },
      include: {
        unit: { select: { unitNumber: true } },
        project: { select: { name: true } },
      },
      orderBy: { date: "desc" },
      take: 20,
    }),
    prisma.maintenanceTask.count({
      where: {
        projectId,
        status: { in: ["PENDING", "IN_PROGRESS"] },
      },
    }),
  ]);

  const totalCharges = Number(chargeAgg._sum.amount ?? 0);
  const totalPaidOnCharges = Number(chargeAgg._sum.paidAmount ?? 0);
  const totalPayments = Number(paymentAgg._sum.amount ?? 0);
  const totalExpenses = Number(expenseAgg._sum.amount ?? 0);
  const otherIncome = Number(incomeAgg._sum.amount ?? 0);
  const totalReceived = totalPayments + otherIncome;
  const fundBalance = computeFundBalance(totalReceived, totalExpenses);
  const outstandingDebt = totalCharges - totalPaidOnCharges;

  const paymentMap = new Map(
    paymentByUnit.map((p) => [p.unitId, Number(p._sum.amount ?? 0)]),
  );

  let unitsWithDebt = 0;
  let unitsWithCredit = 0;
  let totalUnitDebt = 0;
  let totalUnitCredit = 0;

  for (const row of chargeByUnit) {
    const charges = Number(row._sum.amount ?? 0);
    const payments = paymentMap.get(row.unitId) ?? 0;
    const { debt, credit } = computeUnitBalance(charges, payments);
    if (debt > 0) {
      unitsWithDebt++;
      totalUnitDebt += debt;
    }
    if (credit > 0) {
      unitsWithCredit++;
      totalUnitCredit += credit;
    }
  }

  return {
    period,
    totalCharges,
    totalPaidOnCharges,
    totalPayments,
    totalExpenses,
    otherIncome,
    totalReceived,
    fundBalance,
    outstandingDebt,
    overdueCharges,
    partialCharges,
    chargeCount: chargeAgg._count,
    paymentCount: paymentAgg._count,
    expenseCount: expenseAgg._count,
    activeUnits: units,
    unitsWithDebt,
    unitsWithCredit,
    totalUnitDebt,
    totalUnitCredit,
    openMaintenanceTasks: openTasks,
    recentTransactions,
  };
}

export async function getMonthlyFinanceReport(projectId?: string, months = 6) {
  const now = new Date();
  const results = [];

  for (let i = months - 1; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const { start, end } = getMonthRange(year, month);

    const [payments, expenses, charges] = await Promise.all([
      prisma.unitPayment.aggregate({
        where: {
          projectId,
          paymentDate: { gte: start, lte: end },
        },
        _sum: { amount: true },
      }),
      prisma.expense.aggregate({
        where: { projectId, date: { gte: start, lte: end } },
        _sum: { amount: true },
      }),
      prisma.monthlyCharge.aggregate({
        where: { projectId, year, month },
        _sum: { amount: true, paidAmount: true },
      }),
    ]);

    results.push({
      year,
      month,
      label: `${month}/${year}`,
      charges: Number(charges._sum.amount ?? 0),
      paidOnCharges: Number(charges._sum.paidAmount ?? 0),
      payments: Number(payments._sum.amount ?? 0),
      expenses: Number(expenses._sum.amount ?? 0),
      balance:
        Number(payments._sum.amount ?? 0) - Number(expenses._sum.amount ?? 0),
    });
  }

  return results;
}

export async function createBuildingExpense(data: {
  projectId: string;
  title: string;
  amount: number;
  date: Date;
  category?: string;
  description?: string;
}) {
  return prisma.$transaction(async (tx) => {
    const expense = await tx.expense.create({ data });
    await tx.financialTransaction.create({
      data: {
        projectId: data.projectId,
        type: FinancialTransactionType.EXPENSE,
        amount: data.amount,
        description: data.title,
        date: data.date,
        referenceId: expense.id,
        referenceType: "Expense",
        category: data.category ?? "هزینه ساختمان",
      },
    });
    return expense;
  });
}
