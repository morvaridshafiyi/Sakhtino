import { prisma } from "@/lib/prisma";
import { ProjectStatus } from "@prisma/client";

export async function getProjects(includeArchived = false) {
  return prisma.project.findMany({
    where: includeArchived ? undefined : { isArchived: false },
    include: {
      manager: { select: { id: true, name: true } },
      _count: {
        select: {
          units: true,
          workerAssignments: true,
          contractorAssignments: true,
        },
      },
    },
    orderBy: { updatedAt: "desc" },
  });
}

export async function getProjectById(id: string) {
  return prisma.project.findUnique({
    where: { id },
    include: {
      manager: { select: { id: true, name: true, email: true } },
      _count: {
        select: {
          units: true,
          maintenanceTasks: true,
        },
      },
      maintenanceTasks: {
        where: { status: { in: ["PENDING", "IN_PROGRESS"] } },
        orderBy: { createdAt: "desc" },
        take: 5,
        include: { unit: { select: { unitNumber: true } } },
      },
      expenses: { take: 5, orderBy: { date: "desc" } },
    },
  });
}

export async function createProject(data: {
  name: string;
  description?: string;
  address?: string;
  status: ProjectStatus;
  progress: number;
  budget: number;
  startDate?: Date;
  endDate?: Date;
  managerId: string;
}) {
  return prisma.project.create({ data });
}

export async function updateProject(
  id: string,
  data: Partial<{
    name: string;
    description: string;
    address: string;
    status: ProjectStatus;
    progress: number;
    budget: number;
    startDate: Date | null;
    endDate: Date | null;
    isArchived: boolean;
  }>,
) {
  return prisma.project.update({ where: { id }, data });
}

export async function archiveProject(id: string) {
  return prisma.project.update({
    where: { id },
    data: { isArchived: true, status: ProjectStatus.ARCHIVED },
  });
}
