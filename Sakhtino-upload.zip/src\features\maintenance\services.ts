import { prisma } from "@/lib/prisma";
import {
  MaintenancePriority,
  MaintenanceCategory,
  MaintenanceStatus,
} from "@prisma/client";

export async function getMaintenanceTasks(filters: {
  projectId?: string;
  unitId?: string;
  status?: MaintenanceStatus;
} = {}) {
  return prisma.maintenanceTask.findMany({
    where: {
      projectId: filters.projectId,
      unitId: filters.unitId,
      status: filters.status,
    },
    include: {
      project: { select: { id: true, name: true } },
      unit: { select: { id: true, unitNumber: true } },
    },
    orderBy: [{ status: "asc" }, { priority: "desc" }, { createdAt: "desc" }],
  });
}

export async function createMaintenanceTask(data: {
  projectId: string;
  unitId?: string;
  title: string;
  description?: string;
  category: MaintenanceCategory;
  priority: MaintenancePriority;
  estimatedCost?: number;
  scheduledDate?: Date;
  assignedTo?: string;
}) {
  return prisma.maintenanceTask.create({ data });
}

export async function updateMaintenanceTask(
  id: string,
  data: Partial<{
    title: string;
    description: string;
    status: MaintenanceStatus;
    category: MaintenanceCategory;
    priority: MaintenancePriority;
    estimatedCost: number;
    actualCost: number;
    scheduledDate: Date;
    completedDate: Date;
    assignedTo: string;
  }>,
) {
  return prisma.maintenanceTask.update({ where: { id }, data });
}
