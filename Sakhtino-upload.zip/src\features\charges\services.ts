import { prisma } from "@/lib/prisma";
import { computeChargeStatus } from "@/lib/finance/calculations";
import { FinancialTransactionType, PaymentStatus } from "@prisma/client";

export type ChargeFilters = {
  projectId?: string;
  unitId?: string;
  year?: number;
  month?: number;
  status?: PaymentStatus;
};

export async function getMonthlyCharges(filters: ChargeFilters = {}) {
  return prisma.monthlyCharge.findMany({
    where: {
      projectId: filters.projectId,
      unitId: filters.unitId,
      year: filters.year,
      month: filters.month,
      status: filters.status,
    },
    include: {
      unit: { select: { id: true, unitNumber: true, floor: true } },
      project: { select: { id: true, name: true } },
      payments: { orderBy: { paymentDate: "desc" } },
    },
    orderBy: [{ year: "desc" }, { month: "desc" }, { unit: { unitNumber: "asc" } }],
  });
}

export async function createMonthlyCharge(data: {
  unitId: string;
  projectId: string;
  year: number;
  month: number;
  amount: number;
  dueDate: Date;
  description?: string;
}) {
  return prisma.$transaction(async (tx) => {
    const charge = await tx.monthlyCharge.create({
      data: {
        ...data,
        status: PaymentStatus.PENDING,
        paidAmount: 0,
      },
      include: { unit: { select: { unitNumber: true } } },
    });

    await tx.financialTransaction.create({
      data: {
        projectId: data.projectId,
        unitId: data.unitId,
        type: FinancialTransactionType.CHARGE,
        amount: data.amount,
        description: data.description ?? `شارژ ${data.year}/${data.month} — واحد ${charge.unit.unitNumber}`,
        referenceId: charge.id,
        referenceType: "MonthlyCharge",
        category: "شارژ ماهانه",
      },
    });

    return charge;
  });
}

export async function generateMonthlyChargesForBuilding(
  projectId: string,
  year: number,
  month: number,
  dueDate: Date,
) {
  const units = await prisma.unit.findMany({
    where: { projectId, isActive: true, baseCharge: { gt: 0 } },
  });

  const results = [];
  for (const unit of units) {
    const existing = await prisma.monthlyCharge.findUnique({
      where: { unitId_year_month: { unitId: unit.id, year, month } },
    });
    if (existing) continue;

    const charge = await createMonthlyCharge({
      unitId: unit.id,
      projectId,
      year,
      month,
      amount: Number(unit.baseCharge),
      dueDate,
      description: `شارژ ماهانه ${month}/${year}`,
    });
    results.push(charge);
  }
  return results;
}

export async function recordUnitPayment(data: {
  unitId: string;
  projectId: string;
  amount: number;
  monthlyChargeId?: string;
  paymentDate?: Date;
  method?: string;
  reference?: string;
  notes?: string;
}) {
  return prisma.$transaction(async (tx) => {
    const payment = await tx.unitPayment.create({
      data: {
        unitId: data.unitId,
        projectId: data.projectId,
        monthlyChargeId: data.monthlyChargeId,
        amount: data.amount,
        paymentDate: data.paymentDate ?? new Date(),
        method: data.method,
        reference: data.reference,
        notes: data.notes,
      },
      include: {
        unit: { select: { unitNumber: true } },
        monthlyCharge: true,
      },
    });

    if (data.monthlyChargeId) {
      const charge = await tx.monthlyCharge.findUniqueOrThrow({
        where: { id: data.monthlyChargeId },
      });
      const newPaid = Number(charge.paidAmount) + data.amount;
      const status = computeChargeStatus(
        Number(charge.amount),
        newPaid,
        charge.dueDate,
      );
      await tx.monthlyCharge.update({
        where: { id: data.monthlyChargeId },
        data: { paidAmount: newPaid, status },
      });
    }

    await tx.financialTransaction.create({
      data: {
        projectId: data.projectId,
        unitId: data.unitId,
        type: FinancialTransactionType.PAYMENT,
        amount: data.amount,
        description: `پرداخت واحد ${payment.unit.unitNumber}`,
        date: payment.paymentDate,
        referenceId: payment.id,
        referenceType: "UnitPayment",
        category: "شارژ",
      },
    });

    return payment;
  });
}

export async function getUnitPayments(filters: {
  projectId?: string;
  unitId?: string;
  year?: number;
  month?: number;
} = {}) {
  const dateFilter =
    filters.year && filters.month
      ? {
          gte: new Date(filters.year, filters.month - 1, 1),
          lte: new Date(filters.year, filters.month, 0, 23, 59, 59, 999),
        }
      : undefined;

  return prisma.unitPayment.findMany({
    where: {
      projectId: filters.projectId,
      unitId: filters.unitId,
      paymentDate: dateFilter,
    },
    include: {
      unit: { select: { unitNumber: true, floor: true } },
      monthlyCharge: { select: { year: true, month: true } },
      project: { select: { name: true } },
    },
    orderBy: { paymentDate: "desc" },
  });
}
